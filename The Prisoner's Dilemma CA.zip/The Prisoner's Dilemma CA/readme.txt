The Prisoner's Dilemma CA Model



The zip file includes following files:

PrisonersDilemma.ma	        the definition of the cellular model for a b value of 1.85

PrisonersDilemma.bat            the simulation script for the model for 3.2 minutes

PrisonersDilemmaDRW.ma 	        the drawlog script for the model

PrisonersDilemmaLOG.log          the log file for the model

PrisonerDilemmaVideoCapture.avi  an interesting screen capture of the simulation result

PrisonerDilemma.val              the palette file for visualizing the simulation result in CD++ modeler

It will be an interesting excersise to have the simulation run for longer duration and see if the defectors will completely consume the cooperators on workstation with plenty of memory. And also run simulation for several values of b and compare the result.